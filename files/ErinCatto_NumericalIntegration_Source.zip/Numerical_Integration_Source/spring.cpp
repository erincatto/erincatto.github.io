/*
* Copyright (c) 2009 Erin Catto http://www.gphysics.com
*
* Permission to use, copy, modify, distribute and sell this software
* and its documentation for any purpose is hereby granted without fee,
* provided that the above copyright notice appear in all copies.
* Erin Catto makes no representations about the suitability 
* of this software for any purpose.  
* It is provided "as is" without express or implied warranty.
*/

#include <string.h>
#include <stdio.h>
#include <math.h>
#include "glut.h"

// This program simulates mass-spring motion for various integrators.

float mass = 1.0f;
float spring = 4.0f;
float s = spring / mass;
bool advance = false;
const int N = 200;
int count = 0;
float x0 = 1.0f;
float v0 = 0.0f;

struct State
{
	float t, x0, x, v;
};

State stateEE[N+1], stateIE[N+1], stateSE[N+1], stateV[N+1], stateN[N+1];
State stateEx[N+1];

struct Color
{
	Color(float r, float g, float b) : r(r), g(g), b(b) {}
	float r, g, b;
};

void DrawText(int x, int y, char *string)
{
	glMatrixMode(GL_PROJECTION);
	glPushMatrix();
	glLoadIdentity();
	int w = glutGet(GLUT_WINDOW_WIDTH);
	int h = glutGet(GLUT_WINDOW_HEIGHT);
	gluOrtho2D(0, w, h, 0);
	glMatrixMode(GL_MODELVIEW);
	glPushMatrix();
	glLoadIdentity();

	glColor3f(0.9f, 0.6f, 0.6f);
	glRasterPos2i(x, y);
	int length = (int) strlen(string);
	for (int i = 0; i < length; ++i)
	{
		glutBitmapCharacter(GLUT_BITMAP_9_BY_15, string[i]);
	}

	glPopMatrix();
	glMatrixMode(GL_PROJECTION);
	glPopMatrix();
	glMatrixMode(GL_MODELVIEW);
}

void DrawPosition(const State* state1, const State* state2, const Color* color)
{
	glColor3f(color->r, color->g, color->b);
	glBegin(GL_LINES);
	glVertex2f(state1->t, state1->x);
	glVertex2f(state2->t, state2->x);
	glEnd();
}

void ExplicitEuler(State* state2, const State* state1, float h)
{
	state2->t = state1->t + h;
	state2->x0 = state1->x;
	state2->x = state1->x + h * state1->v;
	float acceleration = -s * state1->x;
	state2->v = state1->v + h * acceleration;
}

void ImplicitEuler(State* state2, const State* state1, float h)
{
	// x2 = x1 + h * v2
	// v2 = v1 - h * s * x2
	// v2 = v1 - h * s * (x1 + h * v2)
	// (1 + s * h * h) * v2 = v1 -  h * s * x1
	state2->t = state1->t + h;
	state2->x0 = state1->x;
	float denominator = 1.0f + s * h * h;
	state2->v = (state1->v - h * s * state1->x) / denominator;
	state2->x = state1->x + h * state2->v;
}

void SymplecticEuler(State* state2, const State* state1, float h)
{
	state2->t = state1->t + h;
	state2->x0 = state1->x;
	float acceleration = -s * state1->x;
	state2->v = state1->v + h * acceleration;
	state2->x = state1->x + h * state2->v;
}

void Newton(State* state2, const State* state1, float h)
{
	state2->t = state1->t + h;
	state2->x0 = state1->x;
	float acceleration = -s * state1->x;
	state2->x = state1->x + h * state1->v + 0.5f * h * h * acceleration;
	state2->v = state1->v + h * acceleration;
}

void Verlet(State* state2, const State* state1, float h)
{
	state2->t = state1->t + h;
	state2->x0 = state1->x;
	float acceleration = -s * state1->x;
	state2->x = 2.0f * state1->x - state1->x0 + h * h * acceleration;
	state2->v = (state2->x - state1->x) / h;
}

void Exact(State* state2, const State* state1, float h)
{
	state2->t = state1->t + h;
	float w = sqrtf(s);

	// x = A * sin(w * t) + B * cos(w * t)
	// v = w * A * cos(w * t) - w * B * sin(w * t)
	// x0 = B, v0 = w * A
	float A = v0 / w;
	float B = x0;
	float sn = sinf(w * state2->t), cn = cosf(w * state2->t);
	state2->x0 = state1->x;
	state2->x = A * sn + B * cn;
	state2->v = w * A * cn - w * B * sn;
}

void Integrate()
{
	float h = 1.0f / 5.0f;

	State state0;
	state0.t = 0.0f;
	state0.v = v0;
	state0.x = x0;

	// This makes the Verlet integrator see the initial velocity.
	state0.x0 = state0.x - h * state0.v;

	stateEE[0] = state0;
	stateIE[0] = state0;
	stateSE[0] = state0;
	stateV[0] = state0;
	stateN[0] = state0;
	stateEx[0] = state0;

	for (int i = 0; i < N; ++i)
	{
		ExplicitEuler(stateEE + i + 1, stateEE + i, h);
		ImplicitEuler(stateIE + i + 1, stateIE + i, h);
		SymplecticEuler(stateSE + i + 1, stateSE + i, h);
		Verlet(stateV + i + 1, stateV + i, h);
		Newton(stateN + i + 1, stateN + i, h);
		Exact(stateEx + i + 1, stateEx + i, h);
	}
}

void SimulationLoop()
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	DrawText(5, 15, "Red: EE, Green: IE, Blue: SE/Verlet, Yellow: Newton, White: Exact");
	DrawText(5, 30, "Press: SPACE to advance time, R to reset, (E/D) to adjust spring");

	char buffer[256];
	sprintf(buffer, "Spring = %g", spring);
	DrawText(5, 45, buffer);

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	if (advance && count < N)
	{
		advance = false;
		++count;
	}

	Color colorEE(1.0f, 0.0f, 0.0f);
	Color colorIE(0.0f, 1.0f, 0.0f);
	Color colorSE(0.0f, 0.0f, 1.0f);
	Color colorV(1.0f, 0.0f, 1.0f);
	Color colorN(1.0f, 1.0f, 0.0f);
	Color colorEx(1.0f, 1.0f, 1.0f);
	for (int i = 0; i < count; ++i)
	{
		DrawPosition(stateEE + i, stateEE + i + 1, &colorEE);
		DrawPosition(stateIE + i, stateIE + i + 1, &colorIE);
		DrawPosition(stateSE + i, stateSE + i + 1, &colorSE);
		//DrawPosition(stateV + i, stateV + i + 1, &colorV);
		DrawPosition(stateN + i, stateN + i + 1, &colorN);
		DrawPosition(stateEx + i, stateEx + i + 1, &colorEx);
	}

	glutSwapBuffers();
}


void Keyboard(unsigned char key, int x, int y)
{
	switch (key)
	{
	case 27:
		exit(0);
		break;

	case ' ':
		advance = true;
		break;

	case 'e':
	case 'E':
		spring += 1.0f;
		s = spring / mass;
		Integrate();
		break;

	case 'd':
	case 'D':
		spring -= 1.0f;
		s = spring / mass;
		Integrate();
		break;

	case 'r':
	case 'R':
		count = 0;
		advance = false;
		spring = 4.0f;
		s = spring / mass;
		break;
	}
}

void Reshape(int width, int height)
{
	if (height == 0)
		height = 1;

	glViewport(0, 0, width, height);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();

	float ratio = float(width) / float(height);

	float lowerX = -1.0f * ratio;
	float upperX = 10.0f * ratio;
	float lowerY = -3.0f;
	float upperY = 3.0f;

	gluOrtho2D(lowerX, upperX, lowerY, upperY);
}

int main(int argc, char** argv)
{
	Integrate();

	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_RGBA | GLUT_DOUBLE);
	glutInitWindowSize(800, 800);
	glutCreateWindow("Mass-Spring Motion");

	glutReshapeFunc(Reshape);
	glutDisplayFunc(SimulationLoop);
	glutKeyboardFunc(Keyboard);
	glutIdleFunc(SimulationLoop);

	glutMainLoop();

	return 0;
}
