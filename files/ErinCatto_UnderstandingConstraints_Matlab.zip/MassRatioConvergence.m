% Circle stack simulation using Sequential Impulses
% This script may be run in Matlab or Octave
% Copyright 2014 Erin Catto

% time step
h = 1/60;

% gravity
g = 10;

ratioCount = 20;

iters = zeros(ratioCount, 1);

for r = 1:ratioCount

	% mass of bodies, first body is ground
	masses = [0 1 r];

	% inverse masses
	invMasses = [0 1/masses(2) 1/masses(3)];

	% body velocities
	v = [0 -h*g -h*g];

	% number of constraints
	n = 2;

	% initial constraint impulses
	lambda = [0 0];

	exact = h * g * masses(3)

	% main solver loop, iterate until 95% accuracy
	iter = 0;
	while lambda(2) < 0.95 * exact && iter < 100

		% loop over constraints
		for i = 1:n
			indexA = i + 0;
			indexB = i + 1;
			invMassA = invMasses(indexA);
			invMassB = invMasses(indexB);
			effectiveMass = 1 / (invMassA + invMassB);
			vA = v(indexA);
			vB = v(indexB);
			oldImpulse = lambda(i);
			deltaImpulse = -effectiveMass * (vB - vA);
			lambda(i) = oldImpulse + deltaImpulse;
			vA = vA - invMassA * deltaImpulse;
			vB = vB + invMassB * deltaImpulse;
			v(indexA) = vA;
			v(indexB) = vB;
		end

		iter = iter + 1;
		% lambda
	end

	iters(r) = iter;
end

% plot results
plot([1:ratioCount], iters)
xlabel('mass ratio')
ylabel('iterations')
title('mass ratio solution with 95% convergence')
