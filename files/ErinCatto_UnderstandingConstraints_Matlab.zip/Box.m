% Box simulation using Sequential Impulses
% This script may be run in Matlab or Octave
% Copyright 2014 Erin Catto

% time step
h = 1/60;

% gravity
g = 10;

% half-width of box
a = 1;

% mass of box
m = 1;

% inertia tensor
I = 2/3 * m * a * a;

% inverse mass
invM = 1/m;

% inverse inertia tensor
invI = 1/I;

% body linear and angular velocity
v = [0 -h*g];
w = 0;

% normal vector
normal = [0 1];

% contact point x offset
b = 0.25 * a;

% radius vectors (from center of mass to contact point)
r1 = [-b -b];
r2 = [b, -b];

% radius vector cross normal (lever arm of contact point about center of mass)
rn1 = -b;
rn2 = b;

% effective mass, same for both contact points
meff = 1 / (invM + invI * b * b);

% initial constraint impulses
lambda1 = 0;
lambda2 = 0;

% iteration count
maxIter = 12;

% impulse storage
lambdas = zeros(maxIter + 1, 2);

% main solver loop
for k = 1:maxIter

	% Left contact point
    vn = v(1) * normal(1) + v(2) * normal(2);
	Cdot1 = vn + rn1 * w;
	impulse1 = -meff * Cdot1;
	oldLambda1 = lambda1;
	lambda1 = max(0, lambda1 + impulse1);
	impulse1 = lambda1 - oldLambda1;

	v = v + invM * normal * impulse1;
	w = w + invI * rn1 * impulse1;

	% Right contact point
    vn = v(1) * normal(1) + v(2) * normal(2);
	Cdot2 = vn + rn2 * w;
	impulse2 = -meff * Cdot2;
	oldLambda2 = lambda2;
	lambda2 = max(0, lambda2 + impulse2);
	impulse2 = lambda2 - oldLambda2;

	v = v + invM * normal * impulse2;
	w = w + invI * rn2 * impulse2;

	lambdas(k + 1, :) = [lambda1 lambda2];
end

% exact impulse values for comparison
exact = 0.5 * m * g * h * ones(maxIter + 1, 1);

% plot results
iters = 0:maxIter;
plot(iters, lambdas, iters, exact, '--')
xlabel('iteration')
ylabel('total impulse')
legend('lambda1', 'lambda2', 'exact')
title('Box on pole, b = 0.25 * a')
