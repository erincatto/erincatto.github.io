function d = dot(a, b)
d = a(1) * b(1) + a(2) * b(2);
